__all__ = ['demo', 'compute_kdv','kdv','plot']

from .demo import demo
from .kdv import kdv
from .plot import plot
